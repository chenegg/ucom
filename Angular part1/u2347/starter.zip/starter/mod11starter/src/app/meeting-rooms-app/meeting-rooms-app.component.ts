import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meeting-rooms-app',
  templateUrl: './meeting-rooms-app.component.html',
  styles: []
})
export class MeetingRoomsAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
