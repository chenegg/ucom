export class MeetingRoom {
    id: number=0;
    name: string="";
    size: number=0; 
    projector? : boolean;
    tv?: boolean;
}

