import { Component } from '@angular/core';

@Component({
  selector: 'app-part1',
  templateUrl: './part1.component.html',
  styles: [
  ]
})
export class Part1Component {

}
