import { Component } from '@angular/core';

@Component({
  selector: 'app-page2',
  template: `
    <p>
      page2 works!
    </p>
  `,
  styles: [
  ]
})
export class Page2Component {

}
